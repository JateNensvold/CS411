Programming assignment 3

Use ./run.sh to run the program.